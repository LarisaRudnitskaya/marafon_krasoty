(function () {
  const {
    loadState,
    saveState,
    roseEmoji,
    TOTAL_DAYS,
    MIN_TASKS,
    MAX_TASKS
  } = window.HerbionStorage;

  const GIFT_EMAIL = window.HERBION_CONFIG?.giftEmail || 'herbion@example.com';

  const AGREEMENT_TEXT = `Пользовательское соглашение

1. Общие положения

Настоящее приложение «Herbion Rose Challenge» предназначено для личного использования в рамках 7-дневного марафона ухода за кожей.

2. Использование приложения

Приложение помогает отслеживать ежедневные задания марафона. Все данные хранятся локально на вашем устройстве.

3. Конфиденциальность

Мы не собираем и не передаём персональные данные третьим лицам. Прогресс марафона сохраняется только на вашем устройстве.

4. Ответственность

Приложение предоставляется «как есть». Рекомендации по уходу носят информационный характер и не заменяют консультацию специалиста.

5. Изменения

Разработчик оставляет за собой право обновлять приложение и настоящее соглашение.

Используя приложение, вы подтверждаете согласие с условиями настоящего соглашения.`;

  let state = loadState();
  let currentScreen = 'home';
  let previousAllDone = false;
  let toastTimer = null;

  const app = document.getElementById('app');
  const toastEl = document.getElementById('toast');
  const navHome = document.getElementById('nav-home');
  const navSettings = document.getElementById('nav-settings');
  const bottomNav = document.getElementById('bottom-nav');

  function statusesForDay(day) {
    return state.tasksStatus[day] || Array(state.tasks.length).fill(false);
  }

  function allTasksCompleted() {
    return statusesForDay(state.currentDay).every(Boolean);
  }

  function persist() {
    saveState(state);
    applyTheme();
  }

  function applyTheme() {
    document.documentElement.dataset.theme = state.themeMode;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', state.themeMode === 'dark' ? '#1B3A2F' : '#F48FB1');
    }
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.hidden = true;
    }, 2800);
  }

  function haptic() {
    if (navigator.vibrate) navigator.vibrate(30);
  }

  function renderCheckbox(checked) {
    return `
      <span class="checkbox ${checked ? 'checked' : ''}" aria-hidden="true">
        ${checked ? '<span class="checkmark"></span>' : ''}
      </span>
    `;
  }

  function renderHome() {
    const statuses = statusesForDay(state.currentDay);
    const allDone = statuses.every(Boolean);

    return `
      <section class="screen screen-home">
        <div class="rose-block fade-in">
          <div class="rose-emoji" aria-hidden="true">${roseEmoji(state.currentDay)}</div>
          <h1 class="day-title">День ${state.currentDay} из 7</h1>
        </div>
        <div class="card task-card">
          ${state.tasks.map((task, index) => `
            <label class="task-row">
              <input type="checkbox" class="task-checkbox" data-index="${index}" ${statuses[index] ? 'checked' : ''}>
              ${renderCheckbox(statuses[index])}
              <span class="task-text">${escapeHtml(task)}</span>
            </label>
          `).join('')}
        </div>
        <button class="btn" id="btn-new-day" ${allDone ? '' : 'disabled'}>Начать новый день</button>
        <button class="btn btn-secondary" id="btn-share">Поделиться</button>
      </section>
    `;
  }

  function renderGift() {
    return `
      <section class="screen screen-gift">
        <div class="gift-emoji" aria-hidden="true">🌹✨</div>
        <h1 class="gift-title">Ты прошла марафон! 🌹✨</h1>
        <button class="btn" id="btn-claim-gift">Забрать набор Herbion</button>
        <button class="btn btn-secondary" id="btn-restart">Пройти снова</button>
      </section>
    `;
  }

  function renderSettings() {
    return `
      <section class="screen screen-settings">
        <h1 class="screen-title">Настройки</h1>
        <div class="card">
          <h2>Тема оформления</h2>
          <div class="chip-group">
            <button class="chip ${state.themeMode === 'light' ? 'active' : ''}" data-theme="light">Светлая</button>
            <button class="chip ${state.themeMode === 'dark' ? 'active' : ''}" data-theme="dark">Тёмная</button>
          </div>
        </div>
        <div class="card">
          <h2>Задания марафона</h2>
          <div id="task-editor">
            ${state.tasks.map((task, index) => `
              <div class="task-editor-row">
                <input type="text" class="task-input" data-index="${index}" value="${escapeAttr(task)}" placeholder="Название задания">
                <button class="icon-btn" data-delete="${index}" aria-label="Удалить" ${state.tasks.length <= MIN_TASKS ? 'disabled' : ''}>✕</button>
              </div>
            `).join('')}
          </div>
          <button class="btn btn-outline" id="btn-add-task" ${state.tasks.length >= MAX_TASKS ? 'disabled' : ''}>+ Добавить задание</button>
        </div>
        <div class="card">
          <h2>Контакт для подарка</h2>
          <p class="contact-email">${GIFT_EMAIL}</p>
        </div>
        <button class="btn btn-outline" id="btn-view-agreement">Пользовательское соглашение</button>
      </section>
    `;
  }

  function renderAgreement(showActions) {
    return `
      <section class="screen screen-agreement">
        <h1 class="screen-title">Пользовательское соглашение</h1>
        <div class="card agreement-card">
          <pre class="agreement-text">${AGREEMENT_TEXT}</pre>
        </div>
        ${showActions ? `
          <div class="agreement-actions">
            <button class="btn btn-outline" id="btn-decline">Отклонить</button>
            <button class="btn" id="btn-accept">Принять</button>
          </div>
        ` : `
          <button class="btn" id="btn-close-agreement">Закрыть</button>
        `}
      </section>
    `;
  }

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(text) {
    return escapeHtml(text).replace(/'/g, '&#39;');
  }

  function setScreen(screen) {
    currentScreen = screen;
    bottomNav.hidden = !['home', 'settings'].includes(screen);
    navHome.classList.toggle('active', screen === 'home');
    navSettings.classList.toggle('active', screen === 'settings');
    render();
  }

  function render() {
    if (!state.agreementAccepted) {
      app.innerHTML = renderAgreement(true);
      bindAgreementEvents(true);
      return;
    }

    switch (currentScreen) {
      case 'gift':
        app.innerHTML = renderGift();
        bindGiftEvents();
        break;
      case 'settings':
        app.innerHTML = renderSettings();
        bindSettingsEvents();
        break;
      case 'agreement-view':
        app.innerHTML = renderAgreement(false);
        bindAgreementEvents(false);
        break;
      default:
        app.innerHTML = renderHome();
        bindHomeEvents();
        break;
    }
  }

  function bindHomeEvents() {
    document.querySelectorAll('.task-checkbox').forEach((input) => {
      input.addEventListener('change', (e) => {
        const index = Number(e.target.dataset.index);
        const day = state.currentDay;
        const statuses = [...statusesForDay(day)];
        statuses[index] = e.target.checked;
        state.tasksStatus[day] = statuses;
        haptic();
        persist();
        render();

        const allDone = statuses.every(Boolean);
        if (allDone && !previousAllDone) {
          showToast('Молодец! Можно начинать новый день');
        }
        previousAllDone = allDone;
      });
    });

    document.getElementById('btn-new-day')?.addEventListener('click', () => {
      if (!allTasksCompleted()) return;
      if (state.currentDay >= TOTAL_DAYS) {
        setScreen('gift');
        return;
      }
      state.currentDay += 1;
      state.tasksStatus[state.currentDay] = Array(state.tasks.length).fill(false);
      previousAllDone = false;
      persist();
      setScreen('home');
    });

    document.getElementById('btn-share')?.addEventListener('click', async () => {
      const text = `Я прохожу Herbion Rose Challenge, день ${state.currentDay} из 7`;
      if (navigator.share) {
        try {
          await navigator.share({ title: 'Herbion Rose Challenge', text });
          return;
        } catch (err) {
          if (err.name === 'AbortError') return;
        }
      }
      try {
        await navigator.clipboard.writeText(text);
        showToast('Текст скопирован в буфер обмена');
      } catch {
        showToast(text);
      }
    });

    previousAllDone = allTasksCompleted();
  }

  function bindGiftEvents() {
    document.getElementById('btn-claim-gift')?.addEventListener('click', () => {
      const subject = encodeURIComponent('Заявка на набор Herbion — Rose Challenge');
      const body = encodeURIComponent(
        'Здравствуйте!\n\nЯ прошла марафон Herbion Rose Challenge и хочу забрать набор Herbion.\n\nС уважением.'
      );
      window.location.href = `mailto:${GIFT_EMAIL}?subject=${subject}&body=${body}`;
    });

    document.getElementById('btn-restart')?.addEventListener('click', () => {
      state.currentDay = 1;
      state.tasksStatus = {};
      for (let day = 1; day <= TOTAL_DAYS; day++) {
        state.tasksStatus[day] = Array(state.tasks.length).fill(false);
      }
      previousAllDone = false;
      persist();
      setScreen('home');
    });
  }

  function bindSettingsEvents() {
    document.querySelectorAll('[data-theme]').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.themeMode = btn.dataset.theme;
        persist();
        render();
      });
    });

    document.querySelectorAll('.task-input').forEach((input) => {
      input.addEventListener('input', (e) => {
        const index = Number(e.target.dataset.index);
        state.tasks[index] = e.target.value;
        const normalized = {};
        for (let day = 1; day <= TOTAL_DAYS; day++) {
          const existing = state.tasksStatus[day] || [];
          normalized[day] = Array.from({ length: state.tasks.length }, (_, i) => Boolean(existing[i]));
        }
        state.tasksStatus = normalized;
        persist();
      });
    });

    document.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (state.tasks.length <= MIN_TASKS) {
          showToast('Минимум 1 задание');
          return;
        }
        const index = Number(btn.dataset.delete);
        state.tasks.splice(index, 1);
        const normalized = {};
        for (let day = 1; day <= TOTAL_DAYS; day++) {
          const existing = state.tasksStatus[day] || [];
          normalized[day] = Array.from({ length: state.tasks.length }, (_, i) => Boolean(existing[i]));
        }
        state.tasksStatus = normalized;
        persist();
        render();
      });
    });

    document.getElementById('btn-add-task')?.addEventListener('click', () => {
      if (state.tasks.length >= MAX_TASKS) {
        showToast('Максимум 5 заданий');
        return;
      }
      state.tasks.push('Новое задание');
      const normalized = {};
      for (let day = 1; day <= TOTAL_DAYS; day++) {
        const existing = state.tasksStatus[day] || [];
        normalized[day] = Array.from({ length: state.tasks.length }, (_, i) => Boolean(existing[i]));
      }
      state.tasksStatus = normalized;
      persist();
      render();
    });

    document.getElementById('btn-view-agreement')?.addEventListener('click', () => {
      setScreen('agreement-view');
    });
  }

  function bindAgreementEvents(initial) {
    if (initial) {
      document.getElementById('btn-accept')?.addEventListener('click', () => {
        state.agreementAccepted = true;
        persist();
        setScreen('home');
      });
      document.getElementById('btn-decline')?.addEventListener('click', () => {
        showToast('Для использования приложения необходимо принять соглашение');
      });
    } else {
      document.getElementById('btn-close-agreement')?.addEventListener('click', () => {
        setScreen('settings');
      });
    }
  }

  navHome.addEventListener('click', () => setScreen('home'));
  navSettings.addEventListener('click', () => setScreen('settings'));

  applyTheme();
  render();

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      const swUrl = window.HerbionBase.asset('sw.js');
      const scope = window.HerbionBase.get();
      navigator.serviceWorker.register(swUrl, { scope }).catch(() => {});
    });
  }
})();
