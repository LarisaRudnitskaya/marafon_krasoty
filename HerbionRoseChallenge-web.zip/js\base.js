(function (window) {
  function normalizeBase(path) {
    if (!path) return '/';
    let base = path.trim();
    if (!base.startsWith('/')) base = '/' + base;
    if (!base.endsWith('/')) base += '/';
    return base;
  }

  function detectBasePath() {
    const configured = window.HERBION_CONFIG?.basePath;
    if (configured) return normalizeBase(configured);

    const path = window.location.pathname;
    if (path.endsWith('/index.html')) return normalizeBase(path.replace(/index\.html$/, ''));
    if (path.endsWith('/')) return path;
    const lastSlash = path.lastIndexOf('/');
    return lastSlash >= 0 ? path.slice(0, lastSlash + 1) : '/';
  }

  window.HerbionBase = {
    get: detectBasePath,
    asset: function (file) {
      const base = detectBasePath();
      return base + file.replace(/^\//, '');
    }
  };
})(window);
