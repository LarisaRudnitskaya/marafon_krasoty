(function (window) {
  const STORAGE_KEY = 'herbion_rose_challenge';

  const DEFAULT_TASKS = [
    'Утро: Умывание + тоник',
    'День: Вода + фрукт',
    'Вечер: Снять макияж + крем'
  ];

  const TOTAL_DAYS = 7;
  const MIN_TASKS = 1;
  const MAX_TASKS = 5;

  function normalizeStatus(status, taskCount) {
    const result = {};
    for (let day = 1; day <= TOTAL_DAYS; day++) {
      const existing = status?.[day] || [];
      result[day] = Array.from({ length: taskCount }, (_, i) => Boolean(existing[i]));
    }
    return result;
  }

  function defaultState() {
    return {
      currentDay: 1,
      tasks: [...DEFAULT_TASKS],
      tasksStatus: normalizeStatus({}, DEFAULT_TASKS.length),
      themeMode: 'light',
      agreementAccepted: false
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();

      const parsed = JSON.parse(raw);
      const tasks = Array.isArray(parsed.tasks) && parsed.tasks.length
        ? parsed.tasks.slice(0, MAX_TASKS)
        : [...DEFAULT_TASKS];

      return {
        currentDay: Math.min(Math.max(parsed.currentDay || 1, 1), TOTAL_DAYS),
        tasks,
        tasksStatus: normalizeStatus(parsed.tasksStatus || {}, tasks.length),
        themeMode: parsed.themeMode === 'dark' ? 'dark' : 'light',
        agreementAccepted: Boolean(parsed.agreementAccepted)
      };
    } catch {
      return defaultState();
    }
  }

  function saveState(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      currentDay: state.currentDay,
      tasks: state.tasks,
      tasksStatus: normalizeStatus(state.tasksStatus, state.tasks.length),
      themeMode: state.themeMode,
      agreementAccepted: state.agreementAccepted
    }));
  }

  function roseEmoji(day) {
    switch (day) {
      case 1: return '🌱';
      case 2: return '🌿';
      case 3: return '🌸';
      case 4: return '🌹🌱';
      case 5: return '🌹🌿';
      case 6: return '🌹';
      default: return '🌹✨';
    }
  }

  window.HerbionStorage = {
    loadState,
    saveState,
    roseEmoji,
    DEFAULT_TASKS,
    TOTAL_DAYS,
    MIN_TASKS,
    MAX_TASKS
  };
})(window);
